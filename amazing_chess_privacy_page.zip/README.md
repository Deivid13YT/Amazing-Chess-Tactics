
# Amazing Chess Tactics - Privacy Policy Page

This repository contains the standalone Privacy Policy page for the **Amazing Chess Tactics** website.

## 📁 Structure

- `privacy.html`: The HTML page for the Privacy Policy.
- `style.css`: Custom CSS styles including an animated background and responsive design.

## 📜 Features

- Fully responsive and modern styling
- Animated background
- SEO-ready with meta tags
- GDPR and CCPA compliance sections included

## 📦 Usage

You can host this on GitHub Pages or integrate it into your main website.

## 🧠 License

MIT License
